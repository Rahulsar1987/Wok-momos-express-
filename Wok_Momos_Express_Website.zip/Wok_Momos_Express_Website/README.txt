# Wok & Momos Express Website

Static, mobile-friendly website for Wok & Momos Express — Chef Arup.

## Run
Open `index.html` in a browser.

## Deploy
Upload the complete folder to Netlify, Vercel, GitHub Pages, or any static hosting service.

## Included
- Home / brand section
- Interactive menu category buttons
- 6 final menu pages
- Momos Combo corrected to: 8 PC • Choose Any 4 Flavours • 2 Pc Each
- Call and WhatsApp buttons
- Mobile responsive design
